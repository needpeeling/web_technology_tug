module.exports = {
    handleSearchQuery: function (searchTerm) {
        console.log("Search query for: " + searchTerm);
        // TODO: Handle the Search request
        // This means finding the top X Results that fit the Search Term according to the W2V-Value calculated
    }
}