Frontend ist fertig.
Es fehlen noch Backend und word2vec.

question.html und index.html dienen als template, wie das Ganze schlussendlich ausschauen sollte.
Daraus müsst ihr die darin enthaltenen HTML Schnippsel entnehmen und mit nodejs Fragen und Antworten aus den json files
einfügen.
